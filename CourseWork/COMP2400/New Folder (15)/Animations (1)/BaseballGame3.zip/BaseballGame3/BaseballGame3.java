/* Shows how to make stick animations using predesigned images
   using Frames and Canvas. 
	
	Author: Edgardo Vargas Moya
	        November 24, 2019 
*/
//import java.awt.*;
import java.awt.Color;
import java.awt.Image;
import java.awt.Canvas;
import java.awt.Toolkit;
import java.awt.Graphics;
import javax.swing.JFrame;

//Class to define the Baseball Game object

public class BaseballGame3 extends Canvas
 {
   public void paint(Graphics g) { //g = Graphics object  
     Image img;
     
     for (int j=0; j<5; j++)
		{
		  for (int i=1; i<=11; i++)
		  {  
        
     g.clearRect(0,0,600,300); //Erase image
     
     if (i < 10)
		    {
            Toolkit t = Toolkit.getDefaultToolkit();  
            img = t.getImage("baseball0" + i + ".png"); //Returns an image pixel data from a file
          }
		    else
		    {
            Toolkit t = Toolkit.getDefaultToolkit();  
            img = t.getImage("baseball" + i + ".png"); //Returns an image pixel data from a file
		    }
             
             g.drawImage(img, 120,100,this); //Draw image
             
             //to implement a time delay
             try{
	              Thread.sleep(400); //hold 400ms before next Canvas
	             }
	               catch(InterruptedException e)
	             {
                }
		  }
	  	}      
    }    
   public static void main( String args[] )
 	{
     
     JFrame frame = new JFrame("Baseball Game");//Create the frame and place the title 	 
     frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

     BaseballGame3 canvas = new BaseballGame3(); //Create the canvas and place image
     canvas.setBackground(Color.CYAN); //Change the background color of the canvas to CYAN     
     frame.add(canvas); //Add the canvas to the frame  
     frame.setSize(600,300); //Set frame size  
     frame.setLocationRelativeTo(null); //Set the frame location
     frame.setVisible(true); //Makes the frame visible  
   }
}